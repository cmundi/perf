using System;
using System.Collections.Generic;
using System.Linq;

namespace Benday.PerfCounters.Business
{
    public abstract class CounterSamplesBase
    {
        protected const string CategoryName = "Benday.com Counter Samples";
        protected const string CounterName_AverageOperationTime = "Average Operation Time";
        protected const string CounterName_AverageOperationTimeBase = "Average Operation Time Base";
        protected const string CounterName_OperationCount = "Operation Count";
        protected const string CounterName_OperationsPerSecond = "Operations Per Second";
    }
}
