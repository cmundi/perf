using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace Benday.PerfCounters.Business
{
    public class PerformanceCounterDefinitionManager : CounterSamplesBase
    {
        public static void CreateCounters()
        {
            var countersToCreate = new CounterCreationDataCollection();

            countersToCreate.Add(CreateCounter(
                CounterName_OperationCount,
                "Number of operations.",
                PerformanceCounterType.NumberOfItems64));

            countersToCreate.Add(CreateCounter(
                CounterName_OperationsPerSecond,
                "Number of operations per second.",
                PerformanceCounterType.RateOfCountsPerSecond64));

            countersToCreate.Add(CreateCounter(
                CounterName_AverageOperationTime,
                "Average time per operation.",
                PerformanceCounterType.AverageTimer32));

            countersToCreate.Add(CreateCounter(
                CounterName_AverageOperationTimeBase,
                "Utility counter to support average time per operation.",
                PerformanceCounterType.AverageBase));

            PerformanceCounterCategory.Create(
                CategoryName,
                "Counters for the performance counter samples.",
                PerformanceCounterCategoryType.SingleInstance,
                countersToCreate);
        }

        public static void DeleteCounters()
        {
            PerformanceCounterCategory.Delete(CategoryName);
        }

        private static CounterCreationData CreateCounter(
            string counterName,
            string counterHelp,
            PerformanceCounterType counterType)
        {
            return new CounterCreationData(
                counterName, counterHelp, counterType);
        }
    }
}
