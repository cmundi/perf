using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Benday.PerfCounters.Business
{
    public abstract class OperationBase
    {
        public OperationBase(int id, string operationType)
        {
            m_Id = id;
            m_OperationType = operationType;
        }

        private string m_OperationType;
        public string OperationType
        {
            get { return m_OperationType; }
        }

        protected int m_Id;
        public int Id
        {
            get
            {
                return m_Id;
            }
        }

        protected bool m_IsRunning;
        protected bool m_IsStopRequested = false;
        private void DoStuff()
        {
            var startTicks = DateTime.Now.Ticks;
            
            Random rnd = new Random();
            
            int variation = rnd.Next(OperationDurationTimeVariation);
            int duration = OperationDurationTime + variation;

            Console.WriteLine(String.Format("{0}: Instance '{1}' starting to do stuff for '{2}' ms.", OperationType, Id, duration));
            Thread.Sleep(duration);
            Console.WriteLine(String.Format("{0}: Instance '{1}' did stuff for '{2}' ms.", OperationType, Id, duration));
            
            RecordOperation(DateTime.Now.Ticks - startTicks);
        }

        /// <summary>
        /// Report information to the performance counter manager for this operation type.
        /// </summary>
        /// <param name="duration"></param>
        protected abstract void RecordOperation(long duration);

        private void DoWork(object state)
        {
            try
            {
                m_IsRunning = true;
                Console.WriteLine(String.Format("{0}: Instance '{1}' started.", Id, OperationType));
                while (m_IsStopRequested == false)
                {
                    DoStuff();
                    WaitForNextIteration();
                }
            }
            finally
            {
                m_IsRunning = false;
                Console.WriteLine(String.Format("{0}: Instance '{1}' exited.", Id, OperationType));
            }
        }

        private void WaitForNextIteration()
        {
            Random rnd = new Random();
            int variation = rnd.Next(WaitTimeVariation);
            int duration = WaitTime + variation;
            Console.WriteLine(String.Format("Operation Type #1: Instance '{0}' waiting '{1}' ms for next iteration.", Id, duration));
            Thread.Sleep(duration);
        }
        public int OperationDurationTime { get; set; }
        public int OperationDurationTimeVariation { get; set; }
        public int WaitTime { get; set; }
        public int WaitTimeVariation { get; set; }

        public void Start()
        {
            m_IsStopRequested = false;
            m_IsRunning = false;
            ThreadPool.QueueUserWorkItem(new WaitCallback(DoWork));
        }

        public void Stop()
        {
            m_IsStopRequested = true;
        }

        public bool IsRunning
        {
            get
            {
                return m_IsRunning;
            }
        }
    }
}
