using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace Benday.PerfCounters.Business
{
    public class PerformanceCounterManager
    {
        private static object m_SyncRoot = new object();

        private const string CategoryName = "Benday.com Counter Samples";

        private PerformanceCounterManager()
        {
            Operation1 = new OperationPerformanceCounterManager(
                CategoryName, "Operation 1");

            Operation2 = new OperationPerformanceCounterManager(
                CategoryName, "Operation 2");
        }       

        private static PerformanceCounterManager m_Instance;
        public static PerformanceCounterManager Instance
        {
            get
            {
                if (m_Instance == null)
                {
                    lock (m_SyncRoot)
                    {
                        if (m_Instance == null)
                        {
                            m_Instance = new PerformanceCounterManager();
                        }
                    }
                }

                return m_Instance;
            }
        }

        public OperationPerformanceCounterManager Operation1 { get; private set; }
        public OperationPerformanceCounterManager Operation2 { get; private set; }

        public void CreateCounters()
        {
            var countersToCreate = new CounterCreationDataCollection();
            
            Operation1.RegisterCountersForCreation(countersToCreate);
            Operation2.RegisterCountersForCreation(countersToCreate);

            PerformanceCounterCategory.Create(
                CategoryName,
                CategoryName,
                PerformanceCounterCategoryType.SingleInstance,
                countersToCreate);
        }

        public void DeleteCounters()
        {
            PerformanceCounterCategory.Delete(CategoryName);
        }
    }
}
