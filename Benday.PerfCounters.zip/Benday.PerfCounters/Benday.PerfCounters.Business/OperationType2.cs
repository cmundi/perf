using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Benday.PerfCounters.Business
{
    public class OperationType2 : OperationBase
    {
        public OperationType2(int id)
            : base(id, "Operation Type 2")
        {

        }

        protected override void RecordOperation(long duration)
        {
            // report information to the performance counter manager for this operation type
            PerformanceCounterManager.Instance.Operation2.RecordOperation(duration);
        }
    }
}
