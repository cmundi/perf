using System;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

namespace Benday.PerfCounters.Business
{
    public class PerformanceCounterRuntimeManager : CounterSamplesBase
    {        
        private static PerformanceCounterRuntimeManager m_Instance;
        public static PerformanceCounterRuntimeManager Instance
        {
            get
            {
                if (m_Instance == null)
                {
                    lock (typeof(PerformanceCounterRuntimeManager))
                    {
                        if (m_Instance == null)
                        {
                            m_Instance = new PerformanceCounterRuntimeManager();
                        }
                    }
                }

                return m_Instance;
            }
        }        

        public PerformanceCounterRuntimeManager()
        {
            m_AverageOperationTime = GetPerformanceCounterInstance(CategoryName, CounterName_AverageOperationTime);

            m_AverageOperationTimeBase = GetPerformanceCounterInstance(
                CategoryName, CounterName_AverageOperationTimeBase);

            m_OperationCount = GetPerformanceCounterInstance(
                CategoryName, CounterName_OperationCount);

            m_OperationsPerSecond = GetPerformanceCounterInstance(
                CategoryName, CounterName_OperationsPerSecond);
        }

        private PerformanceCounter GetPerformanceCounterInstance(string categoryName, string counterName)
        {
            return new PerformanceCounter(categoryName, counterName, false);
        }

        private PerformanceCounter m_AverageOperationTime;
        protected PerformanceCounter AverageOperationTime
        {
            get { return m_AverageOperationTime; }
        }

        private PerformanceCounter m_AverageOperationTimeBase;
        protected PerformanceCounter AverageOperationTimeBase
        {
            get { return m_AverageOperationTimeBase; }
        }

        private PerformanceCounter m_OperationCount;
        protected PerformanceCounter OperationCount
        {
            get { return m_OperationCount; }
        }

        private PerformanceCounter m_OperationsPerSecond;
        protected PerformanceCounter OperationsPerSecond
        {
            get { return m_OperationsPerSecond; }
        }

        public void RecordOperation(long duration)
        {
            OperationCount.Increment();
            OperationsPerSecond.Increment();
            AverageOperationTime.IncrementBy(duration);
            AverageOperationTimeBase.Increment();
        }
    }
}
