using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Benday.PerfCounters.Business
{
    public class OperationType1 : OperationBase
    {
        public OperationType1(int id) : base(id, "Operation Type 1")
        {

        }

        protected override void RecordOperation(long duration)
        {
            // report information to the performance counter manager for this operation type
            PerformanceCounterManager.Instance.Operation1.RecordOperation(duration);
        }
    }
}