﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Diagnostics;

namespace Benday.PerfCounters.Business
{
    public class OperationManager
    {
        private List<OperationBase> m_Operations;
        private List<OperationBase> Operations
        {
            get
            {
                if (m_Operations == null)
                {
                    m_Operations = new List<OperationBase>();

                    // create 10 instances of OperationType1 and OperationType2
                    CreateOperations(10);
                }
                return m_Operations;
            }
        }

        private void CreateOperations(int numberOfInstances)
        {
            for (int i = 0; i < numberOfInstances; i++)
            {
                Operations.Add(new OperationType1(i));
                Operations.Add(new OperationType2(i));
            }

            RefreshOperationSettings();
        }

        public void RefreshOperationSettings()
        {
            foreach (var item in Operations)
            {
                item.OperationDurationTime = OperationDurationTime;
                item.OperationDurationTimeVariation = OperationDurationTimeVariation;
                item.WaitTime = WaitTime;
                item.WaitTimeVariation = WaitTimeVariation;
            }
        }

        public bool IsRunning
        {
            get
            {
                foreach (var item in Operations)
                {
                    if (item.IsRunning == true)
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        private int m_WaitTime;
        public int WaitTime
        {
            get
            {
                return m_WaitTime;
            }
            set
            {
                m_WaitTime = value;
            }
        }

        private int m_WaitTimeVariation;
        public int WaitTimeVariation
        {
            get
            {
                return m_WaitTimeVariation;
            }
            set
            {
                m_WaitTimeVariation = value;
            }
        }

        private int m_OperationDurationTime;
        public int OperationDurationTime
        {
            get
            {
                return m_OperationDurationTime;
            }
            set
            {
                m_OperationDurationTime = value;
            }
        }

        private int m_OperationDurationTimeVariation;
        public int OperationDurationTimeVariation
        {
            get
            {
                return m_OperationDurationTimeVariation;
            }
            set
            {
                m_OperationDurationTimeVariation = value;
            }
        }

        private bool m_IsStopRequested = false;

        public void Start()
        {
            foreach (var item in Operations)
            {
                item.Start();
            }
        }

        public void Stop()
        {
            foreach (var item in Operations)
            {
                item.Stop();
            }
        }
    }
}