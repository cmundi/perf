﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Benday.PerfCounters.Business;

namespace Benday.PerfCounters.WinUi
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();            
        }

        private OperationManager m_ManagerInstance;
        public OperationManager ManagerInstance
        {
            get
            {
                if (m_ManagerInstance == null)
                {
                    m_ManagerInstance = new OperationManager();
                }

                return m_ManagerInstance;
            }
        }

        private int GetInt32(TextBox control)
        {
            string value = control.Text;

            int valueAsInt32 = 0;

            if (Int32.TryParse(value, out valueAsInt32) == true)
            {
                return valueAsInt32;
            }
            else
            {
                return 0;
            }
        }

        private void m_timer_Tick(object sender, EventArgs e)
        {
            ManagerInstance.OperationDurationTime = GetInt32(m_DurationTime);
            ManagerInstance.OperationDurationTimeVariation = GetInt32(m_DurationVariation);
            ManagerInstance.WaitTime = GetInt32(m_WaitTime);
            ManagerInstance.WaitTimeVariation = GetInt32(m_WaitVariation);

            ManagerInstance.RefreshOperationSettings();

            m_IsRunning.Text = ManagerInstance.IsRunning.ToString();
        }

        private void m_Start_Click(object sender, EventArgs e)
        {
            ManagerInstance.Start();
        }

        private void m_Stop_Click(object sender, EventArgs e)
        {
            ManagerInstance.Stop();
        }

        private void m_CreateCounters_Click(object sender, EventArgs e)
        {
            try
            {
                PerformanceCounterManager.Instance.CreateCounters();
                MessageBox.Show("Created performance counters.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            } 
        }

        private void m_DeleteCounters_Click(object sender, EventArgs e)
        {
            try
            {
                PerformanceCounterManager.Instance.DeleteCounters();
                MessageBox.Show("Deleted performance counters.");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
