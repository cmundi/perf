﻿namespace Benday.PerfCounters.WinUi
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.m_Start = new System.Windows.Forms.Button();
            this.m_Stop = new System.Windows.Forms.Button();
            this.m_timer = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.m_IsRunning = new System.Windows.Forms.TextBox();
            this.m_DurationTime = new System.Windows.Forms.TextBox();
            this.m_DurationVariation = new System.Windows.Forms.TextBox();
            this.m_WaitTime = new System.Windows.Forms.TextBox();
            this.m_WaitVariation = new System.Windows.Forms.TextBox();
            this.m_CreateCounters = new System.Windows.Forms.Button();
            this.m_DeleteCounters = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // m_Start
            // 
            this.m_Start.Location = new System.Drawing.Point(13, 13);
            this.m_Start.Name = "m_Start";
            this.m_Start.Size = new System.Drawing.Size(95, 23);
            this.m_Start.TabIndex = 0;
            this.m_Start.Text = "Start";
            this.m_Start.UseVisualStyleBackColor = true;
            this.m_Start.Click += new System.EventHandler(this.m_Start_Click);
            // 
            // m_Stop
            // 
            this.m_Stop.Location = new System.Drawing.Point(133, 13);
            this.m_Stop.Name = "m_Stop";
            this.m_Stop.Size = new System.Drawing.Size(95, 23);
            this.m_Stop.TabIndex = 1;
            this.m_Stop.Text = "Stop";
            this.m_Stop.UseVisualStyleBackColor = true;
            this.m_Stop.Click += new System.EventHandler(this.m_Stop_Click);
            // 
            // m_timer
            // 
            this.m_timer.Enabled = true;
            this.m_timer.Tick += new System.EventHandler(this.m_timer_Tick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Is Running";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 76);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Min Duration Time (ms)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(113, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Duration Variation (ms)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "Min Wait Time (ms)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 154);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(95, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Wait Variation (ms)";
            // 
            // m_IsRunning
            // 
            this.m_IsRunning.Location = new System.Drawing.Point(133, 47);
            this.m_IsRunning.Name = "m_IsRunning";
            this.m_IsRunning.Size = new System.Drawing.Size(100, 20);
            this.m_IsRunning.TabIndex = 7;
            // 
            // m_DurationTime
            // 
            this.m_DurationTime.Location = new System.Drawing.Point(133, 73);
            this.m_DurationTime.Name = "m_DurationTime";
            this.m_DurationTime.Size = new System.Drawing.Size(100, 20);
            this.m_DurationTime.TabIndex = 8;
            this.m_DurationTime.Text = "250";
            // 
            // m_DurationVariation
            // 
            this.m_DurationVariation.Location = new System.Drawing.Point(133, 99);
            this.m_DurationVariation.Name = "m_DurationVariation";
            this.m_DurationVariation.Size = new System.Drawing.Size(100, 20);
            this.m_DurationVariation.TabIndex = 9;
            this.m_DurationVariation.Text = "5000";
            // 
            // m_WaitTime
            // 
            this.m_WaitTime.Location = new System.Drawing.Point(133, 125);
            this.m_WaitTime.Name = "m_WaitTime";
            this.m_WaitTime.Size = new System.Drawing.Size(100, 20);
            this.m_WaitTime.TabIndex = 10;
            this.m_WaitTime.Text = "0";
            // 
            // m_WaitVariation
            // 
            this.m_WaitVariation.Location = new System.Drawing.Point(133, 151);
            this.m_WaitVariation.Name = "m_WaitVariation";
            this.m_WaitVariation.Size = new System.Drawing.Size(100, 20);
            this.m_WaitVariation.TabIndex = 11;
            this.m_WaitVariation.Text = "1000";
            // 
            // m_CreateCounters
            // 
            this.m_CreateCounters.Location = new System.Drawing.Point(13, 278);
            this.m_CreateCounters.Name = "m_CreateCounters";
            this.m_CreateCounters.Size = new System.Drawing.Size(95, 23);
            this.m_CreateCounters.TabIndex = 12;
            this.m_CreateCounters.Text = "Create Counters";
            this.m_CreateCounters.UseVisualStyleBackColor = true;
            this.m_CreateCounters.Click += new System.EventHandler(this.m_CreateCounters_Click);
            // 
            // m_DeleteCounters
            // 
            this.m_DeleteCounters.Location = new System.Drawing.Point(133, 278);
            this.m_DeleteCounters.Name = "m_DeleteCounters";
            this.m_DeleteCounters.Size = new System.Drawing.Size(100, 23);
            this.m_DeleteCounters.TabIndex = 13;
            this.m_DeleteCounters.Text = "Delete Counters";
            this.m_DeleteCounters.UseVisualStyleBackColor = true;
            this.m_DeleteCounters.Click += new System.EventHandler(this.m_DeleteCounters_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(380, 313);
            this.Controls.Add(this.m_DeleteCounters);
            this.Controls.Add(this.m_CreateCounters);
            this.Controls.Add(this.m_WaitVariation);
            this.Controls.Add(this.m_WaitTime);
            this.Controls.Add(this.m_DurationVariation);
            this.Controls.Add(this.m_DurationTime);
            this.Controls.Add(this.m_IsRunning);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.m_Stop);
            this.Controls.Add(this.m_Start);
            this.Name = "MainForm";
            this.Text = "benday.com: Performance Counter Sample";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button m_Start;
        private System.Windows.Forms.Button m_Stop;
        private System.Windows.Forms.Timer m_timer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox m_IsRunning;
        private System.Windows.Forms.TextBox m_DurationTime;
        private System.Windows.Forms.TextBox m_DurationVariation;
        private System.Windows.Forms.TextBox m_WaitTime;
        private System.Windows.Forms.TextBox m_WaitVariation;
        private System.Windows.Forms.Button m_CreateCounters;
        private System.Windows.Forms.Button m_DeleteCounters;
    }
}

